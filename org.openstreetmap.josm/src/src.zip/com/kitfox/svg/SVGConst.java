/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kitfox.svg;

/**
 *
 * @author kitfox
 */
public interface SVGConst
{
    public static final String SVG_LOGGER = "svgSalamandeLogger";
}
