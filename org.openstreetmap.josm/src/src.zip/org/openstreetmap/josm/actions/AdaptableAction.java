// License: GPL. For details, see LICENSE file.
package org.openstreetmap.josm.actions;

import javax.swing.Action;

/* allow us to tell the toolbar that name and icon may be changed */
public interface AdaptableAction extends Action {
}
